/**
 * Paint class simulation.
 * @author Mohammad
 * @since 1399-01-21
 */

public class Main1 {
    public static void main(String[] args) {
        Shape circle1 = new Circle1(19.0);
        Shape circle2 = new Circle1(3.0);
        Shape rect1 = new Reactangle1(1.0,4.0,1.0,4.0);
        Shape rect2 = new Reactangle1(8.0,5.0,8.0,5.0);
        Shape rect3 = new Reactangle1(6.0,6.0,6.0,6.0);
        Shape tri1 = new Triangle1(2.0,2.0,2.0);
        Shape  tri = new Triangle1(4.0,4.0,6.0);
        Paint1 paint = new Paint1();
        paint.addShape(circle1);
        paint.addShape(circle2);
        paint.addShape(rect1);
        paint.addShape(rect2);
        paint.addShape(rect3);
        paint.addShape(tri1);
        paint.addShape(tri);
        paint.drawAll();
        paint.printAll();
        paint.describeEqualSides();
    }

}

import java.util.ArrayList;

public class Polygen extends Shape {
    private ArrayList<Double> side;
    public Polygen(Double... args){
        side=new ArrayList<>();
        for (Double i:args
             ) {
            side.add(i);
        }
    }

    public ArrayList<Double> getSide() {
        return side;
    }

    @Override
    public String toString() {
        // make string frolm all sides
        StringBuilder stringBuilder=new StringBuilder();
        int counter=1;
        for (Double i:side
             ) {
            stringBuilder.append(" side");
            stringBuilder.append(counter);
            stringBuilder.append(":  ");
            stringBuilder.append(i);
            counter++;

        }
        return stringBuilder.toString();
    }

}

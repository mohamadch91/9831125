import java.util.ArrayList;

public class Paint {
    private ArrayList<Circle> circles;
    private ArrayList<Triangle> triangles;
    private ArrayList<Rectangle> rectangles;

    public Paint() {
        circles = new ArrayList<>();
        triangles = new ArrayList<>();
        rectangles = new ArrayList<>();

    }

    public void addCircle(Circle circle) {
        circles.add(circle);
    }

    public void addTriangle(Triangle triangle) {
        triangles.add(triangle);
    }

    public void addRectangle(Rectangle rectangle) {
        rectangles.add(rectangle);
    }

    /**
     * show all types of shape information.
     */
    public void drawAll() {
        for (Triangle i : triangles
        ) {

//            System.out.println(i.toString());
            i.draw();
        }
        for (Circle i : circles
        ) {
//            System.out.println(i.toString());
            i.draw();
        }
        for (Rectangle i : rectangles
        ) {
//            System.out.println(i.toString());
            i.draw();
        }
    }

    /**
     * show all types of shape information.
     */
    public void printAll() {
        for (Triangle i : triangles
        ) {
            System.out.println(i.toString());

        }
        for (Circle i : circles
        ) {
            System.out.println(i.toString());

        }
        for (Rectangle i : rectangles
        ) {
            System.out.println(i.toString());

        }
    }

}

public class Shape  {
    public Shape() {
    }

    /**
     * just calculate primetr for routin ways.
     * @param args sides
     * @return perimeter.
     */
    public double calculatePrimeter(Double... args) {
        double sum = 0;
        for (Double i : args
        ) {
            sum += i;
        }
        return sum;
    }

    /**
     * calculate area with routin ways
     * @param args sides
     * @return area
     */
    public double calulateArea(Double... args) {
        double area = 1;
        for (Double i : args
        ) {
            area *= i;
        }
        return Math.pow(area, 0.5);
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public String toString() {
        return super.toString();
    }

    /**
     * show information of shape
     */
    public void draw(){
        System.out.println("Area: "+calulateArea()+" Perimeter"+
                calculatePrimeter());
    }

}
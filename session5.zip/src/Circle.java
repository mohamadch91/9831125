import java.util.Objects;

public class Circle {
    private double radius;
    private static final double PI=3.1415926535;
    public Circle(int radius){
        this.radius=radius;
    }

    public double getRadius() {
        return radius;
    }

    /**
     * calculate perimeter of circle.
     * @return perimeter
     */
    public double calculateperimeter(){
        double perimeter=radius*2*PI;
        return perimeter;
    }

    /**
     * calculate area of circle
     * @return area
     */
    public double calculateArea(){
        double area=Math.pow(radius,2)*PI;
        return area;
    }

    /**
     * show type and information of circle;
     */
    public void draw(){
        System.out.println("Circle "+radius+" Area: "+calculateArea()+" perimeter"+calculateperimeter());
    }

    @Override
    public String toString() {
        return "Circle{" +
                "radius=" + radius
                + " Area="+calculateArea()+" perimeter="+calculateperimeter()+'}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Circle circle = (Circle) o;
        return Double.compare(circle.radius, radius) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(radius);
    }
}

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;

public class Rectangle {
    private ArrayList<Double> sides;

    public Rectangle(double side, double side1, double side2, double side3) {
        int check = 0;
        //check rectangle or not
        if (side == side1 || side == side2 || side == side3)
            check++;
        if (side1 == side2 || side1 == side3)
            check++;
        if (side2 == side3)
            check++;
        if (check >= 2) {
            sides = new ArrayList<>();
            sides.add(side);
            sides.add(side1);
            sides.add(side2);
            sides.add(side3);
        } else
            System.out.println("This is not rectangle");
    }

    /**
     * calculate area of rectangle.
     * @return double area.
     */
    public double calculateArea() {

        HashSet<Double> side = new HashSet<>();
        for (Double i : sides
        ) {
            side.add(i);
        }
        double area = 1;
        for (Double i : side
        ) {
            area *= i;
        }
        return area;
    }

    /**
     * calculate perimeter of rectangle.
     * @return perimeter
     */
    public double calculatePerimeter() {
        double perimeter = 0;
        for (Double i : sides
        ) {
            perimeter += i;
        }
        return perimeter;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!( o instanceof Rectangle )) return false;
        Rectangle rectangle = (Rectangle) o;
        return sides.equals(rectangle.sides);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sides);
    }

    public boolean isSquare() {
        HashSet<Double> side = new HashSet<>();
        for (Double i : sides
        ) {
            side.add(i);
        }
        if (side.size() == 2) {
            return true;
        }
        return false;
    }

    /**
     * show information of draw.
     */
    public void draw() {
        System.out.print("Rectangle");
        HashSet<Double> side = new HashSet<>();
        int counter = 1;
        for (Double i : sides
        ) {
            System.out.print(" side" + counter + ": " + i);
        }
        System.out.println("Area: " + calculateArea() + " Perimeter" + calculatePerimeter());

    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "side1: " + sides.get(0) + " side2: " + sides.get(1) + " sides3: " + sides.get(2)
                + " side4: " + sides.get(3) + " Area: " + calculateArea() + " premetr: " + calculatePerimeter()
                + '}';
    }
}

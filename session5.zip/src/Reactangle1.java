import java.util.ArrayList;
import java.util.HashSet;

public class Reactangle1 extends Polygen {
    public Reactangle1(Double... args){
        super(args);
    }

    /**
     * calcute area of ractangle.
     * @param args  slide of rectangle.
     * @return area.
     */
    @Override
    public double calulateArea(Double... args) {
        ArrayList<Double> sides;
        sides=super.getSide();
        HashSet<Double> side = new HashSet<>();
        for (Double i : sides
        ) {
            side.add(i);
        }
        // two equal sides
        double area = 1;
        for (Double i : side
        ) {
            area *= i;
        }
        return area;
    }

    /**
     * calculate perimetr of rectangle.
     * @param args slide of rect angle
     * @return perimetr of circle.
     */
    @Override
    public double calculatePrimeter(Double... args) {
        ArrayList<Double> sides;
        sides=super.getSide();
        double perimeter = 0;
        for (Double i : sides
        ) {
            perimeter += i;
        }
        return perimeter;
    }

    /**
     * show information of rectangle
     */
    @Override
    public void draw() {
        System.out.println(this.toString());

    }

    @Override
    public String toString() {
        return "Rectangle  "+super.toString()+" Area: "+calulateArea()+" Perimeter: "+calculatePrimeter();
    }

    /**
     * check rectangle is square or no
     * @return if square return true.
     */
    public boolean isSquare() {
        ArrayList<Double> sides;
        sides=super.getSide();

        HashSet<Double> side = new HashSet<>();
        for (Double i : sides
        ) {
            side.add(i);
        }
        if (side.size() == 1) {
            return true;
        }
        return false;
    }
}


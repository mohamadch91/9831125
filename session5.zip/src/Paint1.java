import java.util.ArrayList;

public class Paint1 {
    private ArrayList<Shape> shapes=new ArrayList<>();
    public Paint1(){

    }
    public void addShape(Shape shape){
        shapes.add(shape);
    }

    /**
     * show all type of shapes information.
     */
    public void drawAll(){
        for (Shape i:shapes
             ) {
            i.draw();
        }
    }

    /**
     * same thing with drawAll.
     */
    public void printAll(){
        for (Shape i:shapes
        ) {
            System.out.println(i.toString());
        }
    }

    /**
     * if shapes square or equilateral print.
     */
    public void describeEqualSides(){
        for (Shape i:shapes
             ) {
            //check triangle
            if(i instanceof Triangle1){
                Triangle1 triangle1=null;
                triangle1=(Triangle1)i;
                if(triangle1.isEquilateral())
                    System.out.println(triangle1.toString());
            }
            // check rectangle
            else if(i instanceof Reactangle1){
                Reactangle1 reactangle1=null;
                reactangle1=(Reactangle1) i;
                if(reactangle1.isSquare()){
                    System.out.println(reactangle1.toString());
                }

            }

        }
    }


}

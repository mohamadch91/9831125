import java.util.ArrayList;
import java.util.HashSet;

public class Triangle1 extends Polygen {
    public Triangle1(Double... args){
        super(args);
    }

    /**
     * calculate area.
     * @param args sides
     * @return area.
     */
    @Override
    public double calulateArea(Double... args) {
        ArrayList<Double> sides;
        sides=super.getSide();
        double s = calculatePrimeter() / 2;
        double area = s * ( s - sides.get(0) ) * ( s - sides.get(1) ) * ( s - sides.get(2) );
        area = Math.pow(area, 0.5);
        return area;
    }

    /**
     * calculate perimeter.
     * @param args sides
     * @return doubke of perimeter
     */
    @Override
    public double calculatePrimeter(Double... args) {
        ArrayList<Double> sides;
        sides=super.getSide();
        double sum = 0;
        for (Double i : sides
        ) {
            sum += i;

        }
        return sum;

    }

    @Override
    public String toString() {
        return "Triangle: "+super.toString()+" Area: "+calulateArea()+" Perimeter: "+calculatePrimeter();
    }

    /**
     * show information.
     */
    @Override
    public void draw() {
        System.out.println(this.toString());
    }

    /**
     * check three sides is same or not
     * @return boolean if same return true.
     */
    public boolean isEquilateral(){
        ArrayList<Double> sides;
        sides=super.getSide();
        HashSet<Double> side=new HashSet<>();
        for (Double i:sides
        ) {
            side.add(i);

        }
        if(side.size()==1)
            return true;
    return false;
    }
}


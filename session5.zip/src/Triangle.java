import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;

public class Triangle {
    private ArrayList<Double> sides;

    public Triangle(double side, double side1, double side2) {
        sides = new ArrayList<>();
        sides.add(side);
        sides.add(side1);
        sides.add(side2);
    }

    /**
     * calculate Area.
     *
     * @return area.
     */
    public double calculateArea() {
        double s = calculatePerimeter() / 2;
        double area = s * ( s - sides.get(0) ) * ( s - sides.get(1) ) * ( s - sides.get(2) );
        area = Math.pow(area, 0.5);
        return area;
    }

    /**
     * calculate perimeter.
     *
     * @return sum for perimeter.
     */
    public double calculatePerimeter() {
        double sum = 0;
        for (Double i : sides
        ) {
            sum += i;

        }
        return sum;

    }

    public ArrayList<Double> getSides() {
        return sides;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Triangle triangle = (Triangle) o;
        return Objects.equals(sides, triangle.sides);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sides);
    }

    @Override
    public String toString() {
        // make string of information
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Triangle: ");
        stringBuilder.append("Side1 :  ");
        stringBuilder.append(sides.get(0));
        stringBuilder.append("Side2 :  ");
        stringBuilder.append(sides.get(1));
        stringBuilder.append("Side3 :  ");
        stringBuilder.append(sides.get(2));
        stringBuilder.append(" Area: ");
        stringBuilder.append(calculateArea());
        stringBuilder.append(" Perimeter: ");
        stringBuilder.append(calculatePerimeter());
        return stringBuilder.toString();
    }

    /**
     * check three side is same or not
     *
     * @return if same return true.
     */
    public boolean isEquilateral() {
        HashSet<Double> side = new HashSet<>();
        for (Double i : sides
        ) {
            side.add(i);

        }
        if (side.size() == 1)
            return true;
        return false;
    }

    /**
     * show information of triangle.
     */
    public void draw() {
        System.out.print("Triangle: ");
        for (Double i : sides
        ) {
            System.out.print(i);

        }
        System.out.println("Area: " + calculateArea() + " Perimeter: " + calculatePerimeter());
    }


}

import java.util.Objects;

/**
 *Circle class.
 * @author Mohammad
 */
public class Circle1 extends Shape {
    private double radius;
    private static final double PI=3.1415926535;
    public Circle1(double radius){
        this.radius=radius;
    }
    /**
     * calculate perimeter of circle.
     * @return perimeter
     */
    @Override
    public double calculatePrimeter(Double... args) {
        double area=2*PI*radius;
        return area;
    }
    /**
     * calculate area of circle
     * @return area
     */
    @Override

    public double calulateArea(Double... args) {
        double perimeter=radius*radius*PI;
        return perimeter;
    }
    /**
     * show type and information of circle;
     */
    @Override
    public void draw() {
        System.out.println("Circle: Radius: "+radius+"Perimeter: "+calculatePrimeter()+" Area: "+calulateArea());
    }

    @Override
    public String toString() {
        return "Circle{" +
                "radius=" + radius
                + " Area="+calulateArea()+" perimeter="+calculatePrimeter()+'}';
    }

    public double getRadius() {
        return radius;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!( o instanceof Circle1 )) return false;
        if (!super.equals(o)) return false;
        Circle1 circle1 = (Circle1) o;
        return Double.compare(circle1.getRadius(), getRadius()) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getRadius());
    }
}

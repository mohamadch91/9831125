public class ClockTester {
    /**For testing classes.
     *
     *
     */
    /**
     * main method for testing clock.
     * @param args
     */
    public static void main(String args[]){
        ClockDisplay clockDisplay=new ClockDisplay(1,59,59);
        System.out.println(clockDisplay.getTime());
        clockDisplay.secondTimeTick();
        System.out.println(clockDisplay.getTime());
        clockDisplay.secondTimeTick();
        System.out.println(clockDisplay.getTime());

    }
}

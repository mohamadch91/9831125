public class Main {
    /**
     * To check musicplayer works or not.
     * @param args
     */
        public static void main(String args[]){
        MusicCollection[] categories=new MusicCollection[4];
//        MusicCollection hi=new MusicCollection();
        Music test=new Music("addres1","mohammad","2020");
        Music test1=new Music("my life is going on","??","2017");
        Music test2=new Music("arka mahalle","ahmet kaya","2007");
        Music test3=new Music("je vuex","zaz","?????");
        Music test4=new Music("op","tarkan","2011");
//        hi.addFile(test);
        for (int i=0;i<4;i++){
            categories[i]=new MusicCollection();
        }
        //add files to array list
        categories[0].addFile(test);
        categories[1].addFile(test1);
        categories[2].addFile(test2);
        categories[3].addFile(test3);
        categories[0].addFile(test4);
        categories[0].listAllFiles();
        //test all methods
        categories[0].startPlaying(0);
        categories[1].stopPlaying();
        categories[0].addPlaylist(1);
        categories[0].listPlaylist();
        categories[0].Search("mohammad");
        System.out.println(categories[0].getNumberOfFiles());
        categories[0].removeFile(1);
        categories[0].listAllFiles();
    }
}

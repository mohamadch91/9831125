import java.util.ArrayList;
import java.util.Iterator;

/**
 * A class to hold details of audio files.
 * 
 * @author Mohammad Choupan
 * @version 1398.12.28
 */
public class MusicCollection
{
    // An ArrayList for storing the file names of music files.
   private ArrayList<Music> files;
    private ArrayList<Music> playlist;

    // A player for the music files.
    private MusicPlayer player;
        
    /**
     * Create a MusicCollection
     */
    public MusicCollection()
    {
        files=new ArrayList<Music>();
         playlist=new ArrayList<Music>();
         player=new MusicPlayer();

        
    }
    
    /**
     * Add a file to the collection.
     * @param MusicToAdd The file to be added.
     */
    public void addFile(Music MusicToAdd)
    {
        files.add(MusicToAdd);
        
    }
    /**
     * Add a file to playlist.
     * @param  index The file to be added.
     */
    public void addPlaylist(int index){
        if(validIndex(index)){
        playlist.add(files.get(index));
    }}
    /**
     *  Remove a file from playlist.
     * @param Toremove The file removed
     */
    public void rempvePlaylist(Music Toremove){
        playlist.remove(Toremove);
    }
    /**
     * Return the number of files in the collection.
     * @return The number of files in the collection.
     */
    public int getNumberOfFiles()
    {
        return files.size();
    }
    
    /**
     * List a file from the collection.
     * @param index The index of the file to be listed.
     */
    public void listFile(int index)
    {
        if(validIndex(index)) {
            System.out.println("file address is : " + files.get(index).getFiles());
            System.out.println("Music singer is : " + files.get(index).getSinger());
            System.out.println("file release date is  : " + files.get(index).getRelease());
//        System.out.println("file address is : "+files.get(index).getFiles());
        }
    }
    /**
     * Show a list of playlist members
     */
    public void listPlaylist(){
        Iterator<Music> it=playlist.iterator();
        while (it.hasNext()){
            Music play=it.next();
            System.out.println("file address is : "+play.getFiles());
            System.out.println("Music singer is : "+play.getSinger());
            System.out.println("file release date is  : "+play.getRelease());
        }
    }
        /**
         * Search between musics.
         * @param name name of singer or file name
         */
        public void Search(String name){
            Iterator<Music> it=files.iterator();
            int counter=0;
            while (it.hasNext()){
                counter++;
                Music music=it.next();
                if (music.getSinger().equals(name)||music.getFiles().equals(name)){
                    listFile(counter);
                }
            }
        }
    /**
     * Show a list of all the files in the collection.
     */
    public void listAllFiles()
    {
        for (Music music : files) {
            System.out.println("file address is : " + music.getFiles());
            System.out.println("Music singer is : " + music.getSinger());
            System.out.println("file release date is  : " + music.getRelease());
        }
    }
    
    /**
     * Remove a file from the collection.
     * @param index The index of the file to be removed.
     */
    public void removeFile(int index)

    {
        files.remove(index);
        
    }

    /**
     * Start playing a file in the collection.
     * Use stopPlaying() to stop it playing.
     * @param index The index of the file to be played.
     */
    public void startPlaying(int index)
    {
        if(validIndex(index)) {
            String filename = files.get(index).getFiles();
            player.startPlaying(filename);
            System.out.println("star playing");
        }
    }

    /**
     * Stop the player.
     */
    public void stopPlaying()
    {
        player.stop();
        
    }


    /**
     * Determine whether the given index is valid for the collection.
     * Print an error message if it is not.
     * @param index The index to be checked.
     * @return true if the index is valid, false otherwise.
     */
    private boolean validIndex(int index)
    {
        boolean check=true;
        if(index<0||index>=files.size()){
            check=false;
        }
        // The return value.
        // Set according to whether the index is valid or not.
        return check;
    }

    public ArrayList<Music> getFiles() {
        return files;
    }

    public MusicPlayer getPlayer() {
        return player;
    }

    public ArrayList<Music> getPlaylist() {
        return playlist;
    }

}
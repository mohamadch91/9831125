public class Music {
    private String files;
    private String singer;
    private String release;
    public Music(String files,String singer,String release){
        this.files=files;
        this.singer=singer;
        this.release=release;
    }

    public String getFiles() {
        return files;
    }

    public String getRelease() {
        return release;
    }

    public String getSinger() {
        return singer;
    }

    public void setFiles(String files) {
        this.files = files;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }
}

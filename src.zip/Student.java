public class Student {
    private String firstName;
    private String lastName;
    private String id;
    private int grade;
    public Student(String fname,String lname,String id1){
        firstName=fname;
        lastName=lname;
        id=id1;
        grade=0;

    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public int getGrade() {
        return grade;
    }
    public String getId() {
        return id;
    }
    public String getLastName() {
        return lastName;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void print(){
        System.out.println(lastName+"Student Id:"+id+grade);
    }
}

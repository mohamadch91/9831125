public class Mamad {
}
